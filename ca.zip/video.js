// VIDEO STUFF

	function video_hide_all(){
	//	for (i=0;i<video_elements.length;i++){
			//animatedcollapse.hide(video_elements[i]);
	//	}
	}
	
	function get_video_auth(){
		var get_script = '/includes/get_video_auth_no_youtube.php';
		var mtitle = arguments[0];
		var myoutube = arguments[1];
		var mdescription = arguments[2];
		var mlanguage = arguments[3];
		var mcategory = arguments[4];
		var mtype = arguments[5];
		var mprice = arguments[6];
		var mpublic = arguments[7];
		var mvimeo = arguments[8];
		var mavailable_to = arguments[9];

		//alert('mtitle is ' + mtitle);
		//alert('mdescription is ' + mdescription);
		//alert('mtype is ' + mtype);
		//alert('mlanguage is ' + mlanguage);
		//alert('mcategory is ' + mcategory);
		//alert('mprice is ' + mprice);
		
		if (mtitle == ''){
			alert('Please enter a title.');
			return false;
		} else {
			if (myoutube == '' && mvimeo == ''){
				alert('Please enter a youtube or vimeo id.');
				return false;
			} else {
				if (mdescription == ''){
					alert('Please enter a description.');
					return false;
				} else {
					//alert('message is ' + message);
					  var strURL=get_script + '?mtitle=' + mtitle + '&myoutube=' + myoutube + '&mdescription='+mdescription+'&mtype='+mtype+'&mlanguage='+mlanguage+'&mcategory='+mcategory+'&mprice='+mprice+'&mpublic='+mpublic+'&mvimeo='+mvimeo+'&mavailable_to='+mavailable_to;
					 // alert(strURL);
					  var req = GetXmlHttpObject();
					  if (req){
						req.onreadystatechange = function(){
							  if (req.readyState == 4){// only if "OK"
									if (req.status == 200){
										//alert(req.responseText);
										resp = new String(req.responseText); 
										var resp_array = resp.split('|'); 	
										var post_url = resp_array[0];				
										var next_url = resp_array[1];				
										var token = resp_array[2];	
										var media_id = resp_array[3];	
										location.reload();
										//alert('post_url is ' + post_url);			
										//alert('next_url is ' + next_url);			
										//alert('token is ' + token);			
										//document.getElementById('sending_td').innerHTML=req.responseText;
										/*
										document.getElementById('upload_form').action=post_url + '?nexturl=' + next_url;
										document.getElementById('upload_form').token.value=token;
										document.getElementById('upload_form').media_id.value=media_id;
										$('#save_buttons_upload').show();					
										$('#upload_details_form').hide();					
										$('#upload_form').show();					
										$('#loading_edit_upload_details_form').hide();					
										*/
									} else {
									  //alert('There was a problem while using XMLHTTP:\n' + req.statusText);
									}
							  }
						}
						req.open('GET', strURL, true);
						req.send(null);
						//video_hide_all();
						//animatedcollapse.show('upload_form');
						//showYN(0, 'upload_details_form');
						//showYN(1, 'upload_form');
						$('#save_buttons_upload_details_form').hide();
						//$('#save_buttons_upload').hide();					
						//$('#upload_details_form').show();					
						//$('#upload_form').hide();					
						$('#loading_edit_upload_details_form').show();					
					  } else {
						  alert ("Browser does not support HTTP Request");
						  return;
					  }
					  return false;
				}
			}
		}
		
	}
	function edit_video(){
		var video_array = arguments[0];
		document.getElementById('unavailable_price').innerHTML=video_array[5];
		document.getElementById('edit_details_form').media_id.value=video_array[0];
		document.getElementById('edit_details_form').media_title.value=video_array[1];
		document.getElementById('edit_details_form').media_youtube_id.value=video_array[7];
		document.getElementById('edit_details_form').media_vimeo_id.value=video_array[8];
		document.getElementById('edit_details_form').media_description.value=video_array[2];
		setCheckedValue(document.getElementById('edit_details_form').media_language, video_array[3]);
		//alert(video_array[4]);
		setCheckedValues(document.getElementById('edit_details_form').media_category, video_array[4])
		setCheckedValues(document.getElementById('edit_details_form').media_available_to, video_array[9])
		//document.getElementById('edit_details_form').media_category.value=video_array[4];
		document.getElementById('edit_details_form').media_price.value=video_array[5];
		//alert(video_array[6]);
		if (video_array[6] == 1){
			var yescheck = true;
		} else {
			var yescheck = false;
		}
		document.getElementById('edit_details_form').media_public.checked=yescheck;
		//video_hide_all();
		//animatedcollapse.show('edit_details_form');
	}
	function show_video_price(){
		var video_array = arguments[0];
		document.getElementById('unavailable_price').innerHTML=video_array[5];
		document.getElementById('purchase_media').href='/includes/purchase_media.php?media_id='+video_array[0];
	}
	function show_video_details(){
		//echo "$video_id|$video_name|$video_description|$video_language|$video_category|$video_price";
		var video_array = arguments[0];
		var disp = '<p><b>Title:</b> '+video_array[1]+'</p>';
		disp = disp + '<p><b>Description:</b> '+video_array[2]+'</p>';
		disp = disp + '<p><b>Language:</b> '+video_array[3]+'</p>';
		var cats_array = new Array();
		var cat_id_array = video_array[4].split('~');
		for (var i=0; i<cat_id_array.length;i++){
			cats_array[i] = categories[cat_id_array[i]];
		}
		var cats = cats_array.join(', ');
		if (cats.length > 0){
			disp = disp + '<p><b>Category:</b> '+cats+'</p>';
		}
		document.getElementById('player_description').innerHTML=disp;
		
		// PURCHASE DISPLAY
		document.getElementById('unavailable_price').innerHTML=video_array[5];
		document.getElementById('purchase_media').href='/includes/purchase_media.php?media_id='+video_array[0];
	}
	
	function get_video(){
		var get_script = '/includes/get_video.php';
		var vid_id = arguments[0];
		//alert( vid_id);
		callback = arguments[1];
		if (vid_id == ''){
			return false;
		} else {
			  var strURL=get_script + '?vid_id=' + vid_id;
			  //alert(strURL);
			  var req = GetXmlHttpObject();
			  if (req){
				req.onreadystatechange = function(){
					  if (req.readyState == 4){// only if "OK"
							if (req.status == 200){
								//alert(req.responseText);
								resp = new String(req.responseText); 
								var video_array = resp.split('|'); 
								if (callback && typeof(callback) === "function") {  
									callback(video_array);  
								}  
								//return video_array;
							} else {
							 // alert('There was a problem while using XMLHTTP:\n' + req.statusText);
							}
					  } else {
						//  alert(req.readyState);
					  }
				}
				req.open('GET', strURL, true);
				req.send(null);
			  } else {
				  alert ("Browser does not support HTTP Request");
				  return false;
			  }
			  return false;
		}
	}
	function purchase_media(){
		price = arguments[0];
		alert('price '+ price);
		return false;
		/*
		if (price){
			if (confirm('Are you sure you want to purchase this video. $'+price+' will be removed from your balance.')){
				alert('purchasing '+ price);
				return true;
			} else {
				return false;
			}
		} else {
			return false;
		}
		*/
	}
	function edit_video_details(){
		get_script = '/includes/edit_video_details.php';
		mtitle = arguments[0];
		myoutube = arguments[1];
		mdescription = arguments[2];
		mlanguage = arguments[3];
		mcategory = arguments[4];
		mprice = arguments[5];
		mpublic = arguments[6];
		mid = arguments[7];
		mvimeo = arguments[8];
		mavailable_to = arguments[9];
		if (mvimeo){
			currvid=mvimeo;
		} else {
			currvid=myoutube;
		}
		//alert('mtitle is ' + mtitle);
		//alert('mdescription is ' + mdescription);
		//alert('mtype is ' + mtype);
		//alert('mlanguage is ' + mlanguage);
		//alert('mcategory is ' + mcategory);
		//alert('mprice is ' + mprice);
		//alert('mpublic is ' + mpublic);
		if (mtitle == ''){
			alert('Please enter a title.');
			return false;
		} else {
			if (myoutube == '' && mvimeo == ''){
				alert('Please enter a youtube or vimeo id.');
				return false;
			} else {
				if (mdescription == ''){
					alert('Please enter a description.');
					return false;
				} else {
					//alert('message is ' + message);
					  //video_hide_all();
					  //animatedcollapse.show('loading_edit');
					  var strURL=get_script + '?mtitle=' + mtitle + '&myoutube=' + myoutube + '&mdescription='+mdescription+'&mlanguage='+mlanguage+'&mcategory='+mcategory+'&youtube_id='+currvid+'&mprice='+mprice+'&mpublic='+mpublic+'&mid='+mid+'&mvimeo='+mvimeo+'&mavailable_to='+mavailable_to;
					  //alert(strURL);
					  var req = GetXmlHttpObject();
					  if (req){
						req.onreadystatechange = function(){
							  if (req.readyState == 4){// only if "OK"
									if (req.status == 200){
										//alert(req.responseText);
										resp = new String(req.responseText); 
										//document.getElementById('playerlabel').innerHTML=mtitle;
										document.getElementById(currvid).title=mtitle;
										//document.getElementById(currvid+'_label').innerHTML=mtitle;
										
										if (currvid==mvimeo){
											selectvimeo(currvid);
										} else {
											selectvideo(currvid);
										}
										//video_hide_all();
										//animatedcollapse.show('upload_link');
										//animatedcollapse.show('edit_confirm');
										$('#myModaledit_details_form').modal('hide');
										$('#save_buttons_edit_details_form').show();
										$('#loading_edit_edit_details_form').hide();
										// CHECK IF HAS CURRENT CATEGORY OR NOT
										
											var thesecategories = mcategory.split('~');
											var hascurrentcategory=false;
											if (mcategory!=''){
												for (j=0;j<thesecategories.length;j++) {
													if(currcategory == thesecategories[j]) {
														hascurrentcategory = true;
													}
												}
											} else {
												if (currcategory == 'uncategorized'){
													hascurrentcategory = true;
												}
											}
											//alert('hascurrentcategory is '+hascurrentcategory);
											if (!hascurrentcategory){
												// NOT IN CURRENT CATEGORY, HIDE THE LI
												var currvidli = currvid+'_li';
												$("#"+currvidli).hide('fade');
											}
									} else {
									  alert('There was a problem while using XMLHTTP:\n' + req.statusText);
									}
							  }
						}
						req.open('GET', strURL, true);
						req.send(null);
					  } else {
						  alert ("Browser does not support HTTP Request");
						  return;
					  }
					  return false;
				}
			}
		}
	}
	function delete_media(){
		get_script = '/includes/delete_media.php';
		media_id = arguments[0];
		//alert('media_id is ' + media_id);
		if (media_id != ''){
			//alert('message is ' + message);
			  var strURL=get_script + '?media_id=' + media_id;
			  //alert(strURL);
			  var req = GetXmlHttpObject();
			  if (req){
				req.onreadystatechange = function(){
					  if (req.readyState == 4){// only if "OK"
							if (req.status == 200){
								resp = new String(req.responseText); 
								if (resp!=''){
									alert(resp);
								}
								showYN(0,media_id + '_li' );
								videos.splice(videos.indexOf(media_id), 1);
								selectvideo(videos[0]);
							} else {
							  //alert('There was a problem while using XMLHTTP:\n' + req.statusText);
							}
					  }
				}
				req.open('GET', strURL, true);
				req.send(null);
			  } else {
				  alert ("Browser does not support HTTP Request");
				  return;
			  }
			  return false;
		}
	}
	function confirmDelete(media_id){
	  if (confirm("Are you sure you want to delete the current video?")) {
		delete_media(media_id);
	  }
	}
	
	function checkProcessed(youtube_id){
		get_script = '/includes/video_check_processed.php';
		//alert('media_id is ' + media_id);
		if (youtube_id != ''){
			//alert('message is ' + message);
			  var strURL=get_script + '?youtube_id=' + youtube_id;
			 // alert(strURL);
			  var req = GetXmlHttpObject();
			  if (req){
				req.onreadystatechange = function(){
					  if (req.readyState == 4){// only if "OK"
							if (req.status == 200){
								//alert(req.responseText);
								resp = new String(req.responseText); 
								//alert(resp);
								var resp_array = resp.split('|'); 	
								var status = resp_array[0];		
								switch(status){
									case 'ready':
										// THIS VIDEO HAS BEEN PROCESSED
										alert('Your video has been processed.  It will now be displayed.');
										selectvideo(youtube_id);
										break;
									case 'processing':
										//alert('trying again in 10 seconds');
										setTimeout(function() { 
												checkProcessed(youtube_id); 
											}, 10000) ;
										break;
									case 'restricted':
										var reasonCode = resp_array[1];
										alert('This video has been restricted by Youtube.  Reason is '+reasonCode+'. It will be removed from this list.');
										delete_media(youtube_id);
										break;
									case 'deleted':
										// DELETE THE VIDEO
										alert('This video has been deleted from Youtube.  It will be removed from this list.');
										delete_media(youtube_id);
										break;
									case 'rejected':
										// DELETE THE VIDEO
										var reasonCode = resp_array[1];
										alert('This video has been rejected by Youtube.  Reason is '+reasonCode+'. It will be removed from this list.');
										delete_media(youtube_id);
										break;
									case 'failed':
										// DELETE THE VIDEO
										var reasonCode = resp_array[1];
										alert('This video has failed to upload.  Reason is '+reasonCode+'. It will be removed from this list.');
										delete_media(youtube_id);
										break;
									default:
									   // do nothing
									   break;							
								}
								
							} else {
							  //alert('There was a problem while using XMLHTTP:\n' + req.statusText);
							}
					  }
				}
				req.open('GET', strURL, true);
				req.send(null);
			  } else {
				  alert ("Browser does not support HTTP Request");
				  return;
			  }
			  return false;
		}
	}
	
	function getRadioCheckedValue(form_name, radio_name){  
		var formobj = document.getElementById(form_name);
		var oRadio = formobj.elements[radio_name];    
		for(var i = 0; i < oRadio.length; i++)   {      
			if(oRadio[i].checked)      {         
				return oRadio[i].value;      
			}   
		}    
		return '';
	}
	function setCheckedValue(radioObj, newValue) {
		if(!radioObj)
			return;
		var radioLength = radioObj.length;
		if(radioLength == undefined) {
			radioObj.checked = (radioObj.value == newValue.toString());
			return;
		}
		for(var i = 0; i < radioLength; i++) {
			radioObj[i].checked = false;
			if(radioObj[i].value == newValue.toString()) {
				radioObj[i].checked = true;
			}
		}
	}
	function getCheckboxChecked(form_name, checkname){
		var formobj = document.getElementById(form_name);
		var checkObj = formobj.elements[checkname];    
		var return_array = new Array();
		var j=0;
		//for(var i = 0; i < checkObj.length; i++)   {      
		//	if(checkObj[i].checked){         
		//		return_array[j++] = checkObj[i].value;      
		//	}   
		//} 
		$("input:checkbox[name="+checkname+"]:checked").each(function(){
			return_array.push($(this).val());
		});
		   
		return return_array.join('~');
	}
	function setCheckedValues(checkObj, newValues){
		//alert(JSON.stringify(checkObj));
		var newValues_array = newValues.split('~');
		var newValuesLength = newValues_array.length;
		if(!checkObj){
			return;
		}
		var checkLength = checkObj.length;
		for(var i = 0; i < checkLength; i++) {
			checkObj[i].checked = false;
			for (j=0;j<newValuesLength;j++) {
				if(checkObj[i].value == newValues_array[j]) {
					checkObj[i].checked = true;
				}
			}
		}
	}
	function validate_video_upload() 
	{
	
		m1v=document.getElementById("fileUpload");
	
		if (m1v.value == '') {
			alert('Please select a video to continue.');
			m1v.focus();
			return false;
		} else {
			//showYN(0, 'upload_form');
			//showYN(1, 'loading');
			//video_hide_all();
			//animatedcollapse.show('loading');
			$('#upload_form').hide();
			$('#upload_link').hide();
			$('#loading').show();
			$('#myModalupload_details_form').modal('hide');
			return true;
		}
	}
	
